﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Windows.Forms;
using HtmlDocument = HtmlAgilityPack.HtmlDocument;

namespace TestTask_Ciklum
{
    public partial class Form1 : Form
    {
        public Form1() => InitializeComponent();

        static int HierarchyLevel;

        private async void Button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Enter Start page first!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (string.IsNullOrEmpty(textBox3.Text))
            {
                MessageBox.Show("Enter Hierarchy level first!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            textBox2.Text = "";
            HierarchyLevel = Convert.ToInt32(textBox3.Text);

            IEnumerable<string> Links = await GetLinksFromWebsite(textBox1.Text, HierarchyLevel);
            if (Links is null)
                textBox2.Text += $"Current hierarchy level {1} - ERROR{Environment.NewLine}";
            else await Crawl(Links, 0);
        }

        private async Task Crawl(IEnumerable<string> links, int curentlevel)
        {
            curentlevel++;
            if (links is null)
            {
                textBox2.Text += $"Current hierarchy level {curentlevel} - {new string(' ', curentlevel * 5)}ERROR{Environment.NewLine}";
                return;
            }
            else
                foreach (string link in links)
                {
                    textBox2.Text += $"Current hierarchy level {curentlevel} - {new string(' ', curentlevel * 5) + link + Environment.NewLine}";
                    if (curentlevel + 1 <= HierarchyLevel)
                    {
                        IEnumerable<string> foundLinks = await GetLinksFromWebsite(link, HierarchyLevel);

                        GC.Collect();
                        GC.WaitForPendingFinalizers();

                        await Crawl(foundLinks, curentlevel); //recurtion

                        GC.Collect();
                        GC.WaitForPendingFinalizers();
                    }
                }
        }

        public async Task<IEnumerable<string>> GetLinksFromWebsite(string htmlSource, int level)
        {
            try
            {
                using (WebResponse myWebResponse = await WebRequest.Create(htmlSource).GetResponseAsync())
                {
                    htmlSource = new StreamReader(myWebResponse.GetResponseStream()).ReadToEnd();
                }
            }
            catch (Exception)
            {
                MessageBox.Show($"Level: {level};{Environment.NewLine}Site: {htmlSource}", "Exception - 400", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }

            HtmlDocument doc = new HtmlDocument();
            doc.LoadHtml(htmlSource);
            List<string> listUrLs = new List<string>();
            try
            {
                listUrLs = doc
                            .DocumentNode
                            .SelectNodes("//a[@href]")
                            .Select(node => node.Attributes["href"].Value)
                            .ToList();
            }
            catch (Exception)
            {
                return null;
            }

            string lastHttp = default;
            List<string> listlinks = new List<string>();

            foreach (string url in listUrLs)
                if (url.StartsWith("http"))
                {
                    lastHttp = url;
                    listlinks.Add(url);
                }
                else if(url.StartsWith("/") && lastHttp != default)
                    listlinks.Add(lastHttp + url);

            listlinks = listlinks.Distinct().ToList();
            return listlinks.Take(level);
        }

        private void TextBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != (char)Keys.Delete && e.KeyChar != (char)Keys.Back)
                e.Handled = true;
        }

        private void TextBox2_TextChanged(object sender, EventArgs e)
        {
            Size size = TextRenderer.MeasureText(textBox2.Text, textBox2.Font);
            textBox2.Width = size.Width;
            textBox2.Height = size.Height;
        }

    }
}